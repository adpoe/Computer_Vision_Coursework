%
% @author Anthony Poerio (adp59)
% CS1674 - Computer Vision, HW05
% University of Pittsburgh
% Main script for video search
%

% how to get descriptors, mean?

% run the BOWRepresentation function
[ bow ] = computeBOWRepr( descriptors, means )